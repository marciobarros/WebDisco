package br.unirio.inscricaoppgi.gae.datastore;

public interface DataObject
{
	public long getId();
	
	public void setId(long id);
}