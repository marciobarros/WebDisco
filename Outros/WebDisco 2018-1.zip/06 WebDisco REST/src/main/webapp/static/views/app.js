var App = angular.module('webdiscoApp', ['ngTable', 'ngSanitize']);
