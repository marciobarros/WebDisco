# Importante

Antes de rodar a aplicação, copie o arquivo "configuration-default.properties" do diretório /src/main/java para o arquivo "configuration.properties" no mesmo diretório.
