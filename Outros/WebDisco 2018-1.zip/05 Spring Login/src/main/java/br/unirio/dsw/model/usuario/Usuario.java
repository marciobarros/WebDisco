package br.unirio.dsw.model.usuario;

import java.util.HashSet;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import lombok.Getter;
import lombok.Setter;

/**
 * Classe que representa um usuário do sistema
 * 
 * @author marciobarros
 */
public class Usuario extends User
{
	private static final long serialVersionUID = 7512107428170018274L;

	private @Setter @Getter int id;
	private @Setter @Getter String nome;
	private @Setter @Getter String tokenLogin;
	private @Setter @Getter DateTime dataTokenLogin;
	private @Setter @Getter int contadorFalhasLogin;
	private @Setter @Getter DateTime dataUltimoLogin;
	private @Setter @Getter boolean bloqueado;
	private @Setter @Getter boolean administrador;

	/**
	 * Inicializa um usuário
	 */
	public Usuario(String nome, String email, String senha, boolean bloqueado)
	{
        super(email, senha, true, true, true, !bloqueado, createAuthoritiesFromBasicRole());
		this.id = -1;
		this.nome = nome;
		this.tokenLogin = "";
		this.dataTokenLogin = null;
		this.contadorFalhasLogin = 0;
		this.dataUltimoLogin = null;
		this.bloqueado = bloqueado;
		this.administrador = false;
	}

	/**
	 * Cria os direitos de acesso relacionado ao papel básico do usuário
	 */
	private static Set<GrantedAuthority> createAuthoritiesFromBasicRole()
	{
		Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
        authorities.add(new SimpleGrantedAuthority("ROLE_BASIC"));
		return authorities;
	}
	
	/**
	 * Retorna a data do último login formatada
	 */
	public String getDataUltimoLoginFormatada()
	{
		DateTimeFormatter dtf = DateTimeFormat.forPattern("MM/dd/yyyy HH:mm:ss");
		return dtf.print(dataUltimoLogin);
	}
}