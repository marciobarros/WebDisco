App.factory("topNavigatorDataService", ["$http", function ($http) {
	/*return {
		carrega: function() {
			return $http.get(contextPath + "/edital/summary");
		},
		
		mudaEditalSelecionado: function(id, csrf) {
			return $http.post(contextPath + "/edital/muda/" + id, "", { headers: { "X-CSRF-TOKEN": csrf.value }});
		}
	};*/
}]);
