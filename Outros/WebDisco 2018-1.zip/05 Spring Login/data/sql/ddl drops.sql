DROP TABLE ResultadoChamada;
DROP TABLE InscricaoCampoChamada;
DROP TABLE InscricaoChamada;
DROP TABLE CampoChamada;
DROP TABLE Chamada;
DROP TABLE GestorUnidadeFuncional;
DROP TABLE Usuario;
DROP TABLE UnidadeFuncional;