package br.unirio.webdisco;

public interface Constants
{
	public static final String CD_KEY = "cd";
	public static final String CDLIST_KEY = "cdlist";
	public static final String ERROR_KEY = "error";
}
